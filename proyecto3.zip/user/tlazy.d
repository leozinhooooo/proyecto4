user/tlazy.o: user/tlazy.c kernel/types.h user/user.h
